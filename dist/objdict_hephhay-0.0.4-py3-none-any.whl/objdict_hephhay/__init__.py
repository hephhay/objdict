"""
    Object dot(.) notation implementation for Mapping e.g dict
"""

from objdict_hephhay.util import ObjDict

__all__ = ['ObjDict',]
